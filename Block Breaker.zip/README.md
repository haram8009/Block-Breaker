## SWP2_AD_Project
국민대학교 소프트웨어학부 소프트웨어프로젝트2 AD 프로젝트  
  
- 프로젝트 명 : Block Breaker
- 팀 명 : USC-2 조

## Block Breaker
python으로 제작한 벽돌 깨기 게임이다.
클래식, 타이머, 아케이드 모드를 선택하여 즐길 수 있도록 개발했다.  
